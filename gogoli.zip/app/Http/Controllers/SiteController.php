<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SiteController extends Controller
{
    public function index()
    {
        return view('home');
    }

    public function aboutus()
    {
        return view('aboutus');
    }
    
    public function contact()
    {
        return view('contact');
    }

    public function products($size) {
        return view('products.index',compact('size'));
    }

    public function search() {
        return view('search');
    }

    public function productsindex() {
        return redirect('/catalogs');
    }

    public function catalogs() {
        return view('catalogs');
    }

    public function sellagents() {
        return view('sellagents');
    }

    public function blog() {
        return view('blog');
    }
    public function viewblog() {
        return view('viewblog');
    }
    public function productinfo($name) {
        return view('products.info');
    }
}
