

<?php $__env->startSection('title', __('messages.catalogs')); ?>

<?php $__env->startSection('head'); ?>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<style>
    .catalog-card {
        height: 300px;
        background-size: cover;
        background-position: center;
        margin-bottom: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        border-radius: 5px;
        color: white;
        overflow: hidden;
    }
    .catalog-overlay {
        background: rgba(0, 0, 0, 0.5);
        position: absolute;
        border-radius: 5px;
        inset: 0;
    }
    .catalog-content {
        position: relative;
        text-align: center;
        z-index: 2;
    }
    .catalog-btn {
        background-color: transparent !important;
        color: #d0bc7e !important;
        border: 2px solid #d0bc7e !important;
        transition: all 0.3s ease;
    }
    .catalog-btn:hover {
        background-color: #d0bc7e !important;
        color: #262f40 !important;
    }
    [dir="rtl"] .catalog-title { text-align: right; }
    [dir="ltr"] .catalog-title { text-align: left; }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="py-5 container text-center" dir="<?php echo e(in_array(app()->getLocale(), ['fa','ar']) ? 'rtl' : 'ltr'); ?>">
    <p class="h1 mb-1"><?php echo e(__('messages.catalogs')); ?></p>
    <div class="row">
        <?php for($i = 0; $i < 32; $i++): ?>
        <div class="col-md-3 catalog-item" data-aos="zoom-in">
            <div class="catalog-card"
                 style="background-image: url('https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg');">
                <div class="catalog-overlay"></div>
                <div class="catalog-content">
                    <a href="#" class="btn catalog-btn"><?php echo e(__('messages.download_catalog')); ?></a>
                </div>
            </div>
            <p class="text-black catalog-title">کاتالوگ <?php echo e($i + 1); ?></p>
        </div>
        <?php endfor; ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    VanillaTilt.init(document.querySelectorAll(".catalog-card"), {
        scale: 1.05,
        speed: 400
    });

    const locale = "<?php echo e(strtolower(app()->getLocale())); ?>";
    const catalogItems = document.querySelectorAll(".catalog-item");
    catalogItems.forEach(function(item, index) {
        const titleEl = item.querySelector(".catalog-title");
        if(titleEl) {
            fetch(`https://api.allorigins.win/raw?url=${encodeURIComponent("https://api.amirabolfazl.ir/translate?text=" + encodeURIComponent(titleEl.innerText) + "&lang=" + locale)}`)
            .then(res => res.json())
            .then(data => {
                if(!data.error) titleEl.innerText = data.message.translated;
            }).catch(err => console.error(err));
        }
    });

    AOS.init();
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\hik\Downloads\gogoli\resources\views/catalogs.blade.php ENDPATH**/ ?>