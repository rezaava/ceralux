

<?php $__env->startSection('title', __('messages.products')); ?>

<?php $__env->startSection('head'); ?>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<style>
    .search-container {
        max-width: 600px;
        margin: 0 auto 30px;
    }
    .form-control {
        background-image: url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="%23d0bc7e" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>');
        background-position: right 15px center;
        background-repeat: no-repeat;
        font-family: 'Vazirmatn', sans-serif;
        font-size: 16px;
        padding: 12px 20px 12px 40px;
        border: 2px solid #d0bc7e;
        border-radius: 8px;
        background: rgba(255, 255, 255, 0.9);
        margin-bottom: 20px;
        transition: all 0.3s ease;
    }
    .form-control:focus {
        border-color: #b89f5e;
        box-shadow: 0 0 10px rgba(208, 188, 126, 0.5);
        outline: none;
    }
    .product-card {
        height: 300px;
        background-size: cover;
        background-position: center;
        margin-bottom: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        border-radius: 10px;
        color: white;
        overflow: hidden;
        background: linear-gradient(145deg, rgba(208, 188, 126, 0.2), rgba(230, 211, 163, 0.2));
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }
    .product-card:hover {
        transform: scale(1.03);
        box-shadow: 0 12px 24px rgba(0, 0, 0, 0.2);
    }
    .product-overlay {
        background: linear-gradient(145deg, rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.3));
        position: absolute;
        border-radius: 10px;
        inset: 0;
        transition: opacity 0.3s ease;
    }
    .product-card:hover .product-overlay {
        opacity: 0.7;
    }
    .product-content {
        position: relative;
        text-align: center;
        z-index: 2;
        padding: 20px;
    }
    .product-content h3 {
        font-family: 'Vazirmatn', sans-serif;
        font-size: 1.5rem;
        margin-bottom: 15px;
    }
    .product-btn {
        background-color: transparent !important;
        color: #d0bc7e !important;
        border: 2px solid #d0bc7e !important;
        border-radius: 8px;
        padding: 10px 20px;
        font-family: 'Vazirmatn', sans-serif;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
    }
    .product-btn:hover {
        background-color: #d0bc7e !important;
        color: #262f40 !important;
        transform: scale(1.05);
    }
    .product-btn::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
        transition: left 0.5s ease;
    }
    .product-btn:hover::before {
        left: 100%;
    }
    .product-name {
        font-family: 'Vazirmatn', sans-serif;
        color: #262f40;
        margin-top: 10px;
        text-align: end;
    }
    /* انیمیشن AOS برای کارت‌ها */
    .product-card {
        opacity: 0;
        transform: translateY(20px);
        animation: fadeUp 0.5s ease forwards;
        animation-delay: calc(0.1s * var(--aos-index));
    }
    @keyframes fadeUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    [dir="rtl"] .product-name {
        text-align: right;
    }
    [dir="ltr"] .product-name {
        text-align: left;
    }
    [dir="rtl"] .form-control {
        background-position: left 15px center;
        padding: 12px 40px 12px 20px;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="py-5 container text-center" dir="<?php echo e(in_array(app()->getLocale(), ['fa','ar']) ? 'rtl' : 'ltr'); ?>">
    <p class="h1 mb-1" data-aos="fade-down"><?php echo e(__('messages.products')); ?></p>
    <div class="search-container" data-aos="fade-up" data-aos-delay="200">
        <input type="text" id="myInput" class="form-control" onkeyup="searchProducts()" placeholder="<?php echo e(__('messages.search_products')); ?>" title="<?php echo e(__('messages.search_products')); ?>">
    </div>
    <div class="row" id="productsContainer">
        <div class="col-md-3 product-item" data-aos="zoom-in" style="--aos-index: 1;">
            <div class="product-card" style="background-image: url('https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg');">
                <div class="product-overlay"></div>
                <div class="product-content">
                    <h3 class="product-title"><?php echo e(__('messages.porcelain_blue')); ?></h3>
                    <a href="/products/info/1x1" class="btn product-btn"><?php echo e(__('messages.product_info')); ?></a>
                </div>
            </div>
            <p class="product-name"><?php echo e(__('messages.porcelain_blue')); ?></p>
        </div>
        <div class="col-md-3 product-item" data-aos="zoom-in" style="--aos-index: 2;">
            <div class="product-card" style="background-image: url('https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg');">
                <div class="product-overlay"></div>
                <div class="product-content">
                    <h3 class="product-title"><?php echo e(__('messages.porcelain_classic')); ?></h3>
                    <a href="/products/info/1x2" class="btn product-btn"><?php echo e(__('messages.product_info')); ?></a>
                </div>
            </div>
            <p class="product-name"><?php echo e(__('messages.porcelain_classic')); ?></p>
        </div>
        <div class="col-md-3 product-item" data-aos="zoom-in" style="--aos-index: 3;">
            <div class="product-card" style="background-image: url('https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg');">
                <div class="product-overlay"></div>
                <div class="product-content">
                    <h3 class="product-title"><?php echo e(__('messages.porcelain_modern')); ?></h3>
                    <a href="/products/info/1x3" class="btn product-btn"><?php echo e(__('messages.product_info')); ?></a>
                </div>
            </div>
            <p class="product-name"><?php echo e(__('messages.porcelain_modern')); ?></p>
        </div>
        <div class="col-md-3 product-item" data-aos="zoom-in" style="--aos-index: 4;">
            <div class="product-card" style="background-image: url('https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg');">
                <div class="product-overlay"></div>
                <div class="product-content">
                    <h3 class="product-title"><?php echo e(__('messages.porcelain_bronze')); ?></h3>
                    <a href="/products/info/1x4" class="btn product-btn"><?php echo e(__('messages.product_info')); ?></a>
                </div>
            </div>
            <p class="product-name"><?php echo e(__('messages.porcelain_bronze')); ?></p>
        </div>
        <!-- محصولات تکراری برای تست جستجو -->
        <div class="col-md-3 product-item" data-aos="zoom-in" style="--aos-index: 5;">
            <div class="product-card" style="background-image: url('https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg');">
                <div class="product-overlay"></div>
                <div class="product-content">
                    <h3 class="product-title"><?php echo e(__('messages.porcelain_luxury')); ?></h3>
                    <a href="/products/info/1x5" class="btn product-btn"><?php echo e(__('messages.product_info')); ?></a>
                </div>
            </div>
            <p class="product-name"><?php echo e(__('messages.porcelain_luxury')); ?></p>
        </div>
        <div class="col-md-3 product-item" data-aos="zoom-in" style="--aos-index: 6;">
            <div class="product-card" style="background-image: url('https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg');">
                <div class="product-overlay"></div>
                <div class="product-content">
                    <h3 class="product-title"><?php echo e(__('messages.porcelain_minimal')); ?></h3>
                    <a href="/products/info/1x6" class="btn product-btn"><?php echo e(__('messages.product_info')); ?></a>
                </div>
            </div>
            <p class="product-name"><?php echo e(__('messages.porcelain_minimal')); ?></p>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // افکت VanillaTilt برای کارت‌های محصول
        if (typeof VanillaTilt !== 'undefined') {
            VanillaTilt.init(document.querySelectorAll(".product-card"), {
                scale: 1.05,
                speed: 400,
                glare: true,
                maxGlare: 0.3
            });
        }

        // تابع جستجوی محصولات
        function searchProducts() {
            var input, filter, container, items, title, i, txtValue;
            input = document.getElementById("myInput");
            filter = input.value.toUpperCase();
            container = document.getElementById("productsContainer");
            items = container.getElementsByClassName("product-item");
            
            for (i = 0; i < items.length; i++) {
                title = items[i].getElementsByClassName("product-title")[0];
                if (title) {
                    txtValue = title.textContent || title.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        items[i].style.display = "";
                    } else {
                        items[i].style.display = "none";
                    }
                }
            }
        }

        // فعال کردن جستجو با دکمه Enter
        document.getElementById("myInput").addEventListener("keypress", function(event) {
            if (event.key === "Enter") {
                searchProducts();
            }
        });

        // فعال کردن AOS
        if (typeof AOS !== 'undefined') {
            AOS.init();
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Downloads\tile\resources\views/search.blade.php ENDPATH**/ ?>