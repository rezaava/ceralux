

<?php $__env->startSection('title', __('messages.product_info')); ?>

<?php $__env->startSection('head'); ?>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://unpkg.com/vanilla-tilt@1.7.0/dist/vanilla-tilt.min.js"></script>
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<style>
    .article {
        border: 10px solid #ffffff;
        background: linear-gradient(145deg, #fff8e4, #f5e9c6);
        padding: 20px;
        border-radius: 12px;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        margin-bottom: 40px;
        position: relative;
        overflow: hidden;
        font-family: 'Vazirmatn', sans-serif;
    }
    .article:hover {
        transform: scale(1.03);
        box-shadow: 0 12px 24px rgba(0, 0, 0, 0.2);
    }
    .article::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
        transition: left 0.5s ease;
    }
    .article:hover::before {
        left: 100%;
    }
    .overlay-container {
        position: relative;
        display: inline-block;
        cursor: pointer;
        width: 100%;
        border-radius: 10px;
        overflow: hidden;
    }
    .overlay-container img {
        display: block;
        width: 100%;
        height: 350px;
        object-fit: cover;
        border-radius: 10px;
    }
    .overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: radial-gradient(circle, rgba(0, 0, 0, 0.5) 70%, rgba(0, 0, 0, 0) 100%);
        opacity: 0;
        transition: opacity 0.3s ease;
        border-radius: 10px;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    .overlay i {
        font-size: 40px;
        color: #d0bc7e;
    }
    .overlay-container:hover .overlay {
        opacity: 1;
    }
    .article h2 {
        color: #d0bc7e;
        font-size: 2rem;
        margin: 15px 0;
    }
    .article p {
        color: #262f40;
        font-size: 1rem;
        margin-bottom: 10px;
    }
    .article ul {
        color: #262f40;
        font-size: 1rem;
        margin-bottom: 15px;
        padding-right: 20px;
    }
    .article h5 {
        color: #b89f5e;
        font-weight: bold;
        font-size: 1.3rem;
        margin: 15px 0;
    }
    .article .text-muted {
        font-size: 0.9rem;
        color: #666;
    }
    .gallery-container {
        margin-bottom: 40px;
    }
    .gallery-item {
        position: relative;
        margin-bottom: 20px;
    }
    .gallery-item p {
        font-family: 'Vazirmatn', sans-serif;
        color: #262f40;
        text-align: center;
        margin-top: 10px;
        font-size: 0.9rem;
    }
    .sizes {
        display: flex;
        justify-content: center;
        align-items: end;
        gap: 25px;
        flex-wrap: wrap;
        margin-top: 40px;
    }
    .tile {
        display: flex;
        flex-direction: column;
        align-items: center;
        transition: all 0.3s ease;
    }
    .tile:hover {
        transform: scale(1.05);
    }
    .tile a {
        text-decoration: none;
        color: inherit;
    }
    .box {
        border: 2px solid #d0bc7e;
        background: linear-gradient(145deg, #fff8e4, #f5e9c6);
        border-radius: 8px;
        position: relative;
        overflow: hidden;
        transition: all 0.3s ease;
    }
    .box:hover::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
        transition: left 0.5s ease;
        left: 100%;
    }
    .selected-box {
        border: 4px solid #b89f5e;
        box-shadow: 0 0 10px rgba(208, 188, 126, 0.5);
    }
    .label {
        margin-top: 12px;
        color: #d0bc7e;
        font-family: 'Vazirmatn', sans-serif;
        font-weight: bold;
        font-size: 1.1rem;
    }
    .article-btn {
        background-color: transparent !important;
        color: #d0bc7e !important;
        border: 2px solid #d0bc7e !important;
        border-radius: 8px;
        padding: 10px 20px;
        font-family: 'Vazirmatn', sans-serif;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
        margin: 5px;
    }
    .article-btn:hover {
        background-color: #d0bc7e !important;
        color: #262f40 !important;
        transform: scale(1.05);
    }
    .article-btn::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
        transition: left 0.5s ease;
    }
    .article-btn:hover::before {
        left: 100%;
    }
    /* انیمیشن AOS */
    .article, .gallery-item, .tile {
        opacity: 0;
        transform: translateY(20px);
        animation: fadeUp 0.5s ease forwards;
        animation-delay: calc(0.1s * var(--aos-index));
    }
    @keyframes fadeUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    [dir="rtl"] .article ul {
        padding-right: 20px;
        padding-left: 0;
    }
    [dir="ltr"] .article ul {
        padding-left: 20px;
        padding-right: 0;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="py-5 container" dir="<?php echo e(in_array(app()->getLocale(), ['fa','ar']) ? 'rtl' : 'ltr'); ?>">
    <div id="contentContainer">
        <div class="article article-item" data-aos="fade-up" style="--aos-index: 1;">
            <div class="overlay-container clickable-img" data-src="https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg">
                <img src="https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg" class="article-img" alt="<?php echo e(__('messages.product_image_alt')); ?>">
                <div class="overlay"><i class="fa-solid fa-magnifying-glass"></i></div>
            </div>
            <h2 class="article-title"><?php echo e(__('messages.product_title')); ?></h2>
            <p class="text-muted"><?php echo e(__('messages.product_date')); ?></p>
            <p><?php echo e(__('messages.product_description')); ?></p>
            <p><?php echo e(__('messages.features')); ?>:</p>
            <ul>
                <li><?php echo e(__('messages.feature_1')); ?></li>
                <li><?php echo e(__('messages.feature_2')); ?></li>
                <li><?php echo e(__('messages.feature_3')); ?></li>
                <li><?php echo e(__('messages.feature_4')); ?></li>
                <li><?php echo e(__('messages.feature_5')); ?></li>
            </ul>
            <h5><?php echo e(__('messages.price')); ?>: <?php echo e(__('messages.product_price')); ?></h5>
            <div class="d-flex justify-content-start">
                <a href="<?php echo e(route('sellagents')); ?>" class="btn article-btn"><?php echo e(__('messages.view_agents')); ?></a>
            </div>
        </div>

        <!-- Gallery -->
        <div class="row gallery-container" data-aos="fade-up" style="--aos-index: 2;">
            <div class="col-lg-4 col-md-12 mb-4 mb-lg-0">
                <div class="overlay-container clickable-img gallery-item" data-src="https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg" data-title="<?php echo e(__('messages.gallery_item_1')); ?>">
                    <img src="https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg" alt="<?php echo e(__('messages.gallery_item_1')); ?>"/>
                    <div class="overlay"><i class="fa-solid fa-magnifying-glass"></i></div>
                </div>
                <p><?php echo e(__('messages.gallery_item_1')); ?></p>
                <div class="overlay-container clickable-img gallery-item mb-4" data-src="https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg" data-title="<?php echo e(__('messages.gallery_item_2')); ?>">
                    <img src="https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg" alt="<?php echo e(__('messages.gallery_item_2')); ?>"/>
                    <div class="overlay"><i class="fa-solid fa-magnifying-glass"></i></div>
                </div>
                <p><?php echo e(__('messages.gallery_item_2')); ?></p>
            </div>
            <div class="col-lg-4 mb-4 mb-lg-0">
                <div class="overlay-container clickable-img gallery-item mb-4" data-src="https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg" data-title="<?php echo e(__('messages.gallery_item_3')); ?>">
                    <img src="https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg" alt="<?php echo e(__('messages.gallery_item_3')); ?>"/>
                    <div class="overlay"><i class="fa-solid fa-magnifying-glass"></i></div>
                </div>
                <p><?php echo e(__('messages.gallery_item_3')); ?></p>
                <div class="overlay-container clickable-img gallery-item mb-4" data-src="https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg" data-title="<?php echo e(__('messages.gallery_item_4')); ?>">
                    <img src="https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg" alt="<?php echo e(__('messages.gallery_item_4')); ?>"/>
                    <div class="overlay"><i class="fa-solid fa-magnifying-glass"></i></div>
                </div>
                <p><?php echo e(__('messages.gallery_item_4')); ?></p>
            </div>
            <div class="col-lg-4 mb-4 mb-lg-0">
                <div class="overlay-container clickable-img gallery-item mb-4" data-src="https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg" data-title="<?php echo e(__('messages.gallery_item_5')); ?>">
                    <img src="https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg" alt="<?php echo e(__('messages.gallery_item_5')); ?>"/>
                    <div class="overlay"><i class="fa-solid fa-magnifying-glass"></i></div>
                </div>
                <p><?php echo e(__('messages.gallery_item_5')); ?></p>
                <div class="overlay-container clickable-img gallery-item mb-4" data-src="https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg" data-title="<?php echo e(__('messages.gallery_item_6')); ?>">
                    <img src="https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg" alt="<?php echo e(__('messages.gallery_item_6')); ?>"/>
                    <div class="overlay"><i class="fa-solid fa-magnifying-glass"></i></div>
                </div>
                <p><?php echo e(__('messages.gallery_item_6')); ?></p>
            </div>
        </div>

        <!-- سایزها -->
        <div class="sizes mt-5" data-aos="fade-up" style="--aos-index: 3;">
            <?php $__currentLoopData = __('messages.size_options'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="tile size-item" style="--aos-index: <?php echo e($loop->index + 4); ?>;">
                <a href="<?php echo e(route('products', ['size' => $size])); ?>">
                    <div class="box <?php echo e($size == '120×240' ? 'selected-box' : ''); ?>" style="width:<?php echo e($label['width']); ?>; height:<?php echo e($label['height']); ?>;"></div>
                    <div class="label" data-title="<?php echo e($size); ?>"><?php echo e($size); ?></div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<!-- Modal برای بزرگنمایی عکس‌ها -->
<div class="modal fade" id="myModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <img id="modalImage" src="" class="img-fluid"/>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    // نمایش مودال عکس‌ها
    document.querySelectorAll('.overlay-container.clickable-img').forEach(img => {
        img.addEventListener('click', function() {
            document.getElementById('modalImage').src = this.dataset.src;
            let modal = new bootstrap.Modal(document.getElementById('myModal'));
            modal.show();
        });
    });

    AOS.init();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Downloads\tile\resources\views/products/info.blade.php ENDPATH**/ ?>