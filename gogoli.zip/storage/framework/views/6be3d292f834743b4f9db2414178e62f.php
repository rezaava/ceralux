

<?php $__env->startSection('title', __('messages.blog')); ?>

<?php $__env->startSection('head'); ?>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <style>
        .article-img {
            width: 100%;
            height: auto;
            margin-bottom: 10px;
        }

        .article-btn {
            background-color: transparent !important;
            color: #d0bc7e !important;
            border: 2px solid #d0bc7e !important;
            width: 100%;
            transition: all 0.3s ease;
        }

        .article-btn:hover {
            background-color: #d0cm7e !important;
            color: #262f40 !important;
        }

        .article {
            border: solid 10px #ffffff;
            background-color: #fff8e4;
            padding: 10px;
            border-radius: 5px;
            height: 100%;
            display: flex;
            flex-direction: column;
        }
        
        .article-content {
            flex-grow: 1;
        }
        
        .article-title {
            color: #262f40;
            font-size: 1.5rem;
            margin-bottom: 10px;
            min-height: 72px;
        }
        
        .article-date {
            color: #6c757d;
            margin-bottom: 10px;
        }
        
        .article-excerpt {
            color: #262f40;
            margin-bottom: 15px;
            flex-grow: 1;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="py-5 container" dir="<?php echo e(in_array(app()->getLocale(), ['fa','ar']) ? 'rtl' : 'ltr'); ?>">
        <h1 class="text-center mb-5" style="color: #d0bc7e;"><?php echo e(__('messages.blog')); ?></h1>
        <div class="row">
            <?php for($i = 0; $i < 20; $i++): ?>
            <div class="col-md-3 mb-4" data-aos="zoom-in">
                <div class="article">
                    <img src="https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg"
                        class="article-img" alt="<?php echo e(__('messages.article_image_alt')); ?>">
                    <div class="article-content">
                        <h2 class="article-title"><?php echo e(__('messages.article_title')); ?></h2>
                        <p class="article-date"><?php echo e(__('messages.article_date')); ?></p>
                        <p class="article-excerpt"><?php echo e(__('messages.article_excerpt')); ?></p>
                    </div>
                    <a class="btn article-btn" href="/blog/<?php echo e($i + 1); ?>"><?php echo e(__('messages.read_more')); ?></a>
                </div>
            </div>
            <?php endfor; ?>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("scripts"); ?>
<script>
    AOS.init();
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Downloads\tile\resources\views/blog.blade.php ENDPATH**/ ?>