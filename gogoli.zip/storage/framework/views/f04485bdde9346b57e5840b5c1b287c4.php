

<?php $__env->startSection("title", __("messages.contact")); ?>

<?php $__env->startSection('head'); ?>
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="https://unpkg.com/vanilla-tilt@1.7.0/dist/vanilla-tilt.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://unpkg.com/splide@4.0.7/dist/css/splide.min.css">
<script src="https://unpkg.com/splide@4.0.7/dist/js/splide.min.js"></script>
<style>
    .sellagent {
        background: linear-gradient(145deg, #fff8e4, #f5e9c6);
        padding: 15px;
        border-radius: 10px;
        margin-bottom: 20px;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        position: relative;
        overflow: hidden;
        font-family: 'Vazirmatn', sans-serif;
        transition: all 0.3s ease;
    }
    .sellagent:hover {
        transform: scale(1.02);
        box-shadow: 0 12px 24px rgba(0, 0, 0, 0.2);
    }
    .sellagent::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
        transition: left 0.5s ease;
    }
    .sellagent:hover::before {
        left: 100%;
    }
    .sellagent-img {
        height: 250px;
        width: 100%;
        object-fit: cover;
        border-radius: 8px;
    }
    .sellagent h2 {
        color: #d0bc7e;
        font-size: 1.8rem;
        margin-bottom: 10px;
    }
    .sellagent p {
        color: #262f40;
        font-size: 1rem;
        margin-bottom: 10px;
    }
    .contact-card {
        background: linear-gradient(145deg, #fff8e4, #f5e9c6);
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        margin-bottom: 20px;
        font-family: 'Vazirmatn', sans-serif;
        position: relative;
        overflow: hidden;
        transition: all 0.3s ease;
    }
    .contact-card:hover {
        transform: scale(1.02);
        box-shadow: 0 12px 24px rgba(0, 0, 0, 0.2);
    }
    .contact-card::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
        transition: left 0.5s ease;
    }
    .contact-card:hover::before {
        left: 100%;
    }
    .contact-card h2 {
        color: #d0bc7e;
        font-size: 1.8rem;
        margin-bottom: 10px;
    }
    .contact-card p {
        color: #262f40;
        font-size: 1rem;
    }
    .contact-card i {
        font-size: 2.5rem;
        margin-bottom: 10px;
        transition: all 0.3s ease;
    }
    .contact-card i.fa-phone {
        color: #28a745;
    }
    .contact-card i.fa-map-marker {
        color: #dc3545;
    }
    .contact-card i:hover {
        transform: scale(1.1);
    }
    .slider-global-caption, .slider-global-caption-l {
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        background: linear-gradient(145deg, #fff8e4, #f5e9c6);
        padding: 20px 30px;
        border-radius: 10px;
        color: #262f40;
        text-align: center;
        width: 35%;
        height: 180px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15);
        font-family: 'Vazirmatn', sans-serif;
    }
    .slider-global-caption {
        right: 10%;
    }
    .slider-global-caption-l {
        left: 10%;
    }
    .slider-global-caption h2, .slider-global-caption-l h2 {
        font-size: 1.8rem;
        color: #d0bc7e;
        margin-bottom: 10px;
    }
    .slider-global-caption p, .slider-global-caption-l p {
        font-size: 1rem;
        color: #262f40;
    }
    .slider-global-caption i, .slider-global-caption-l i {
        font-size: 2.5rem;
        margin-bottom: 10px;
    }
    .contact-btn {
        background-color: transparent !important;
        color: #d0bc7e !important;
        border: 2px solid #d0bc7e !important;
        border-radius: 8px;
        padding: 10px 20px;
        font-family: 'Vazirmatn', sans-serif;
        transition: all 0.3s ease;
        position: relative;
        overflow: hidden;
        margin-top: 10px;
    }
    .contact-btn:hover {
        background-color: #d0bc7e !important;
        color: #262f40 !important;
        transform: scale(1.05);
    }
    .contact-btn::before {
        content: '';
        position: absolute;
        top: 0;
        left: -100%;
        width: 100%;
        height: 100%;
        background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.4), transparent);
        transition: left 0.5s ease;
    }
    .contact-btn:hover::before {
        left: 100%;
    }
    .video-slider video {
        width: 100%;
        height: 400px;
        object-fit: cover;
    }
    /* انیمیشن AOS */
    .contact-card, .sellagent {
        opacity: 0;
        transform: translateY(20px);
        animation: fadeUp 0.5s ease forwards;
        animation-delay: calc(0.1s * var(--aos-index));
    }
    @keyframes fadeUp {
        from {
            opacity: 0;
            transform: translateY(20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    @media (max-width: 1185px) {
        .slider-global-caption, .slider-global-caption-l {
            width: 80%;
            height: 150px;
            padding: 15px;
        }
        .slider-global-caption h2, .slider-global-caption-l h2 {
            font-size: 1.5rem;
        }
        .slider-global-caption p, .slider-global-caption-l p {
            font-size: 0.9rem;
        }
        .video-slider video {
            height: 300px;
        }
    }
    [dir="rtl"] .slider-global-caption {
        right: 10%;
        left: auto;
    }
    [dir="rtl"] .slider-global-caption-l {
        left: 10%;
        right: auto;
    }
    [dir="ltr"] .slider-global-caption {
        right: auto;
        left: 10%;
    }
    [dir="ltr"] .slider-global-caption-l {
        left: auto;
        right: 10%;
    }
    [dir="rtl"] .sellagent .text-end {
        text-align: right !important;
    }
    [dir="ltr"] .sellagent .text-end {
        text-align: left !important;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section dir="ltr" class="splide video-slider" aria-label="Video Slider">
    <div class="splide__track">
        <ul class="splide__list">
            <li class="splide__slide">
                <video autoplay muted loop>
                    <source src="https://abadistile.com/wp-content/uploads/2023/11/slider-abadis-tile-4-3.mp4" type="video/mp4">
                </video>
            </li>
            <li class="splide__slide">
                <video autoplay muted loop>
                    <source src="https://abadistile.com/wp-content/uploads/2023/11/slider-abadis-tile-2-3-1.m4v" type="video/mp4">
                </video>
            </li>
        </ul>
    </div>
    <div class="row" id="contact-slider" style="display: none;">
        <div class="col-6">
            <div class="slider-global-caption" data-aos="fade-up" style="--aos-index: 1;">
                <i class="fas fa-phone"></i>
                <h2><?php echo e(__('messages.phone_number')); ?></h2>
                <p><?php echo e(__('messages.company_phone')); ?></p>
            </div>
        </div>
        <div class="col-6">
            <div class="slider-global-caption-l" data-aos="fade-up" style="--aos-index: 2;">
                <i class="fas fa-map-marker"></i>
                <h2><?php echo e(__('messages.address')); ?></h2>
                <p><?php echo e(__('messages.company_address')); ?></p>
            </div>
        </div>
    </div>
</section>

<section class="py-5 container text-center" dir="<?php echo e(in_array(app()->getLocale(), ['fa','ar']) ? 'rtl' : 'ltr'); ?>">
    <div id="contact-no-slider" style="display: none;">
        <div class="row">
            <div class="col-md-6">
                <div class="contact-card" data-aos="fade-up" style="--aos-index: 3;">
                    <i class="fas fa-phone"></i>
                    <h2><?php echo e(__('messages.phone_number')); ?></h2>
                    <p><?php echo e(__('messages.company_phone')); ?></p>
                </div>
            </div>
            <div class="col-md-6">
                <div class="contact-card" data-aos="fade-up" style="--aos-index: 4;">
                    <i class="fas fa-map-marker"></i>
                    <h2><?php echo e(__('messages.address')); ?></h2>
                    <p><?php echo e(__('messages.company_address')); ?></p>
                </div>
            </div>
        </div>
    </div>

    <p class="h1 mb-4" style="color: #d0bc7e; font-family: 'Vazirmatn', sans-serif;"><?php echo e(__('messages.agents')); ?></p>
    <div class="row">
        <?php $__currentLoopData = __('messages.agents_list'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6">
            <div class="sellagent" data-aos="fade-up" style="--aos-index: <?php echo e($loop->index + 5); ?>;">
                <div class="row">
                    <div class="col-md-6 text-end">
                        <h2><?php echo e($agent['title']); ?></h2>
                        <p><?php echo e($agent['address']); ?></p>
                        <p><?php echo e($agent['phone']); ?></p>
                        <a href="tel:<?php echo e($agent['phone']); ?>" class="btn contact-btn"><?php echo e(__('messages.contact_agent')); ?></a>
                    </div>
                    <div class="col-md-6">
                        <img src="https://abadistile.com/wp-content/uploads/2024/06/eleman-frisco-lobby-120240-ll-1536x1536.jpg" class="sellagent-img">
                    </div>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // اسلایدر ویدیویی
        new Splide('.splide', {
            type: 'fade',
            autoplay: true,
            pagination: false,
            rewind: true,
            pauseOnHover: false,
            pauseOnFocus: false,
            pause: false,
            speed: 800
        }).mount();

        // مدیریت نمایش اسلایدر و کارت‌ها بر اساس عرض صفحه
        const contactSlider = document.getElementById("contact-slider");
        const contactNoSlider = document.getElementById("contact-no-slider");
        function updateDisplay() {
            if (window.innerWidth >= 1185) {
                contactSlider.style.display = "block";
                contactNoSlider.style.display = "none";
            } else {
                contactSlider.style.display = "none";
                contactNoSlider.style.display = "block";
            }
        }
        updateDisplay();
        window.addEventListener('resize', updateDisplay);

        // افکت VanillaTilt برای کپشن‌های اسلایدر و تصاویر نمایندگی‌ها
        VanillaTilt.init(document.querySelectorAll(".slider-global-caption, .slider-global-caption-l, .sellagent-img"), {
            scale: 1.05,
            speed: 400,
            glare: true,
            maxGlare: 0.3
        });

        // مدیریت نوار نویگیشن
        const navbar = document.querySelector('.navbar');
        const toggler = document.querySelector('.navbar-toggler');
        navbar.classList.remove('colored');
        navbar.classList.remove('sticky-top');
        navbar.classList.add('fixed-top');

        window.addEventListener('scroll', function () {
            if (window.scrollY > 5) {
                navbar.classList.add('colored');
            } else {
                navbar.classList.remove('colored');
            }
        });

        toggler.addEventListener('click', function () {
            navbar.classList.add('colored');
        });

        AOS.init();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc\Downloads\tile\resources\views/contact.blade.php ENDPATH**/ ?>